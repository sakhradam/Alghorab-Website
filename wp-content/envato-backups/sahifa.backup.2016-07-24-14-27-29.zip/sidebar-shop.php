<aside id="sidebar">
	<div class="theiaStickySidebar">
<?php
	dynamic_sidebar( 'shop-widget-area' );
?>
	</div><!-- .theiaStickySidebar /-->
</aside><!-- #sidebar /-->